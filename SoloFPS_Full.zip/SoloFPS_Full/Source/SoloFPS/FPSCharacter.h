#pragma once
#include "CoreMinimal.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/Character.h"
#include "FPSCharacter.generated.h"

class AWeaponBase;

UCLASS()
class SOLOFPS_API AFPSCharacter : public ACharacter
{
    GENERATED_BODY()
public:
    AFPSCharacter();

    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

    virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
    virtual void Tick(float DeltaTime) override;
    virtual void BeginPlay() override;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Camera")
    UCameraComponent* FirstPersonCameraComponent;

    UPROPERTY(EditDefaultsOnly, Category="Weapon")
    TSubclassOf<AWeaponBase> StarterWeaponClass;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Weapon")
    AWeaponBase* CurrentWeapon;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Replicated, Category="Health")
    float MaxHealth = 100.f;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, ReplicatedUsing=OnRep_Health, Category="Health")
    float Health;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="State")
    bool bIsAiming = false;

    UFUNCTION(BlueprintCallable, Category="Health")
    void ApplyDamage(float DamageAmount);

    UFUNCTION(BlueprintCallable, Category="Health")
    float GetHealthPercent() const;

    UFUNCTION(BlueprintCallable, Category="Weapon")
    int32 GetCurrentAmmo() const;

    UFUNCTION(BlueprintCallable, Category="Weapon")
    int32 GetReserveAmmo() const;

    UFUNCTION()
    void OnRep_Health();

protected:
    void MoveForward(float Value);
    void MoveRight(float Value);
    void Turn(float Value);
    void LookUp(float Value);
    void StartJump();
    void StopJump();
    void StartSprint();
    void StopSprint();
    void ToggleCrouch();
    void StartFire();
    void StopFire();
    void StartReload();
    void StartAim();
    void StopAim();

    UFUNCTION(Server, Reliable)
    void ServerApplyDamage(float DamageAmount);

    float HealthLocalBackup;
    bool bIsSprinting = false;
    bool bIsCrouchedLocal = false;
};
