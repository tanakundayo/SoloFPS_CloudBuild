#include "FPSCharacter.h"
#include "WeaponBase.h"
#include "GameFramework/PlayerController.h"
#include "Components/InputComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Net/UnrealNetwork.h"

AFPSCharacter::AFPSCharacter()
{
    PrimaryActorTick.bCanEverTick = true;
    bReplicates = true;
    FirstPersonCameraComponent = CreateDefaultSubobject<UCameraComponent>(TEXT("FirstPersonCamera"));
    FirstPersonCameraComponent->SetupAttachment(GetCapsuleComponent());
    FirstPersonCameraComponent->SetRelativeLocation(FVector(0.f,0.f,64.f));
    FirstPersonCameraComponent->bUsePawnControlRotation = true;

    Health = MaxHealth;

    GetCharacterMovement()->MaxWalkSpeed = 400.f;
    GetCharacterMovement()->JumpZVelocity = 420.f;
}

void AFPSCharacter::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);
    DOREPLIFETIME(AFPSCharacter, Health);
    DOREPLIFETIME(AFPSCharacter, MaxHealth);
}

void AFPSCharacter::BeginPlay()
{
    Super::BeginPlay();

    if (HasAuthority())
    {
        if (StarterWeaponClass)
        {
            FActorSpawnParameters SpawnParams;
            SpawnParams.Owner = this;
            CurrentWeapon = GetWorld()->SpawnActor<AWeaponBase>(StarterWeaponClass, SpawnParams);
            if (CurrentWeapon)
            {
                USkeletalMeshComponent* MeshComp = GetMesh();
                if (MeshComp)
                {
                    CurrentWeapon->AttachToComponent(MeshComp, FAttachmentTransformRules::SnapToTargetNotIncludingScale, TEXT("hand_r_socket"));
                }
                else
                {
                    CurrentWeapon->AttachToComponent(RootComponent, FAttachmentTransformRules::SnapToTargetNotIncludingScale);
                }
                CurrentWeapon->SetOwner(this);
            }
        }
    }
}

void AFPSCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
    Super::SetupPlayerInputComponent(PlayerInputComponent);

    PlayerInputComponent->BindAxis("MoveForward", this, &AFPSCharacter::MoveForward);
    PlayerInputComponent->BindAxis("MoveRight", this, &AFPSCharacter::MoveRight);
    PlayerInputComponent->BindAxis("Turn", this, &AFPSCharacter::Turn);
    PlayerInputComponent->BindAxis("LookUp", this, &AFPSCharacter::LookUp);

    PlayerInputComponent->BindAction("Jump", IE_Pressed, this, &AFPSCharacter::StartJump);
    PlayerInputComponent->BindAction("Jump", IE_Released, this, &AFPSCharacter::StopJump);

    PlayerInputComponent->BindAction("Sprint", IE_Pressed, this, &AFPSCharacter::StartSprint);
    PlayerInputComponent->BindAction("Sprint", IE_Released, this, &AFPSCharacter::StopSprint);

    PlayerInputComponent->BindAction("Crouch", IE_Pressed, this, &AFPSCharacter::ToggleCrouch);

    PlayerInputComponent->BindAction("Fire", IE_Pressed, this, &AFPSCharacter::StartFire);
    PlayerInputComponent->BindAction("Fire", IE_Released, this, &AFPSCharacter::StopFire);

    PlayerInputComponent->BindAction("Reload", IE_Pressed, this, &AFPSCharacter::StartReload);

    PlayerInputComponent->BindAction("Aim", IE_Pressed, this, &AFPSCharacter::StartAim);
    PlayerInputComponent->BindAction("Aim", IE_Released, this, &AFPSCharacter::StopAim);
}

void AFPSCharacter::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);
}

void AFPSCharacter::MoveForward(float Value) { if (Value != 0.f) AddMovementInput(GetActorForwardVector(), Value * (bIsSprinting ? 1.5f : 1.0f)); }
void AFPSCharacter::MoveRight(float Value)  { if (Value != 0.f) AddMovementInput(GetActorRightVector(), Value); }
void AFPSCharacter::Turn(float Value)       { AddControllerYawInput(Value); }
void AFPSCharacter::LookUp(float Value)     { AddControllerPitchInput(Value); }
void AFPSCharacter::StartJump()             { Jump(); }
void AFPSCharacter::StopJump()              { StopJumping(); }
void AFPSCharacter::StartSprint()           { bIsSprinting = true; GetCharacterMovement()->MaxWalkSpeed = 650.f; }
void AFPSCharacter::StopSprint()            { bIsSprinting = false; GetCharacterMovement()->MaxWalkSpeed = 400.f; }
void AFPSCharacter::ToggleCrouch()          { if (bIsCrouchedLocal) { UnCrouch(); bIsCrouchedLocal = false; } else { Crouch(); bIsCrouchedLocal = true; } }

void AFPSCharacter::StartFire()  { if (CurrentWeapon) CurrentWeapon->StartFire(); }
void AFPSCharacter::StopFire()   { if (CurrentWeapon) CurrentWeapon->StopFire(); }
void AFPSCharacter::StartReload(){ if (CurrentWeapon) CurrentWeapon->StartReload(); }
void AFPSCharacter::StartAim()   { bIsAiming = true; }
void AFPSCharacter::StopAim()    { bIsAiming = false; }

void AFPSCharacter::ApplyDamage(float DamageAmount)
{
    if (HasAuthority())
    {
        Health = FMath::Clamp(Health - DamageAmount, 0.f, MaxHealth);
        if (Health <= 0.f)
        {
            AController* C = GetController();
            if (C) C->UnPossess();
            Destroy();
        }
    }
    else
    {
        ServerApplyDamage(DamageAmount);
    }
}

void AFPSCharacter::ServerApplyDamage_Implementation(float DamageAmount)
{
    ApplyDamage(DamageAmount);
}

void AFPSCharacter::OnRep_Health()
{
    // client-side reaction e.g., play hit UI
}

float AFPSCharacter::GetHealthPercent() const { return (MaxHealth > 0.f) ? Health / MaxHealth : 0.f; }

int32 AFPSCharacter::GetCurrentAmmo() const
{
    if (CurrentWeapon) return CurrentWeapon->GetCurrentAmmo();
    return 0;
}
int32 AFPSCharacter::GetReserveAmmo() const
{
    if (CurrentWeapon) return CurrentWeapon->GetReserveAmmo();
    return 0;
}
