#include "WeaponBase.h"
#include "Kismet/GameplayStatics.h"
#include "FPSCharacter.h"
#include "DrawDebugHelpers.h"
#include "TimerManager.h"
#include "Components/SceneComponent.h"
#include "Net/UnrealNetwork.h"

AWeaponBase::AWeaponBase()
{
    PrimaryActorTick.bCanEverTick = true;
    WeaponRoot = CreateDefaultSubobject<USceneComponent>(TEXT("WeaponRoot"));
    RootComponent = WeaponRoot;
    SetReplicates(true);
}

void AWeaponBase::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);
    DOREPLIFETIME(AWeaponBase, CurrentAmmoInMag);
    DOREPLIFETIME(AWeaponBase, CurrentReserve);
}

void AWeaponBase::BeginPlay()
{
    Super::BeginPlay();
    CurrentAmmoInMag = MagazineSize;
    CurrentReserve = ReserveAmmo;
    TimeBetweenShots = FireRate;
    MyOwnerActor = GetOwner();
}

void AWeaponBase::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);
}

bool AWeaponBase::CanFire() const
{
    return CurrentAmmoInMag > 0;
}

void AWeaponBase::ConsumeAmmo()
{
    if (HasAuthority())
    {
        CurrentAmmoInMag = FMath::Max(0, CurrentAmmoInMag - 1);
    }
}

void AWeaponBase::StartFire()
{
    if (!CanFire()) return;

    if (GetOwner()->HasAuthority())
    {
        float FirstDelay = FMath::Max(LastFireTime + TimeBetweenShots - GetWorld()->TimeSeconds, 0.f);
        GetWorldTimerManager().SetTimer(TimerHandle_TimeBetweenShots, this, &AWeaponBase::FireShot, TimeBetweenShots, bIsAutomatic, FirstDelay);
    }
    else
    {
        // Client requests server to fire: send view info (origin + direction)
        APawn* OwnerPawn = Cast<APawn>(GetOwner());
        if (OwnerPawn)
        {
            FVector EyeLoc;
            FRotator EyeRot;
            OwnerPawn->GetActorEyesViewPoint(EyeLoc, EyeRot);
            ServerFire(EyeLoc, EyeRot.Vector());
        }
    }
}

void AWeaponBase::StopFire()
{
    if (GetOwner()->HasAuthority())
    {
        GetWorldTimerManager().ClearTimer(TimerHandle_TimeBetweenShots);
    }
    else
    {
        // Optionally tell server to stop if you implemented continuous fire tracking
    }
}

void AWeaponBase::FireShot()
{
    if (!CanFire())
    {
        StopFire();
        return;
    }

    APawn* MyOwnerPawn = Cast<APawn>(GetOwner());
    if (!MyOwnerPawn) return;

    FVector EyeLocation;
    FRotator EyeRot;
    MyOwnerPawn->GetActorEyesViewPoint(EyeLocation, EyeRot);

    FVector ShotDirection = EyeRot.Vector();
    FVector TraceEnd = EyeLocation + ShotDirection * Range;

    FHitResult Hit;
    FCollisionQueryParams QueryParams;
    QueryParams.AddIgnoredActor(this);
    QueryParams.AddIgnoredActor(GetOwner());
    QueryParams.bTraceComplex = true;

    if (GetWorld()->LineTraceSingleByChannel(Hit, EyeLocation, TraceEnd, ECC_Visibility, QueryParams))
    {
        if (ImpactEffect)
        {
            UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), ImpactEffect, Hit.ImpactPoint, Hit.ImpactNormal.Rotation());
        }
        AActor* HitActor = Hit.GetActor();
        if (HitActor)
        {
            UGameplayStatics::ApplyPointDamage(HitActor, Damage, ShotDirection, Hit, MyOwnerPawn->GetController(), this, nullptr);
        }
    }

    if (MuzzleFlash) UGameplayStatics::SpawnEmitterAttached(MuzzleFlash, RootComponent);
    if (ShotSound) UGameplayStatics::PlaySoundAtLocation(this, ShotSound, GetActorLocation());

    ConsumeAmmo();
    LastFireTime = GetWorld()->TimeSeconds;

    MulticastFireEffects();
}

void AWeaponBase::ServerFire_Implementation(const FVector& Origin, const FVector& ShootDir)
{
    // Server validates origin/direction if needed then perform authoritative trace
    FVector TraceEnd = Origin + ShootDir * Range;
    FHitResult Hit;
    FCollisionQueryParams QueryParams;
    APawn* OwnerPawn = Cast<APawn>(GetOwner());
    QueryParams.AddIgnoredActor(GetOwner());

    if (GetWorld()->LineTraceSingleByChannel(Hit, Origin, TraceEnd, ECC_Visibility, QueryParams))
    {
        if (ImpactEffect)
        {
            UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), ImpactEffect, Hit.ImpactPoint, Hit.ImpactNormal.Rotation());
        }
        if (Hit.GetActor())
        {
            UGameplayStatics::ApplyPointDamage(Hit.GetActor(), Damage, ShootDir, Hit, OwnerPawn ? OwnerPawn->GetController() : nullptr, this, nullptr);
        }
    }

    // consume ammo on server
    ConsumeAmmo();

    // play effects for everyone
    MulticastFireEffects();
}

bool AWeaponBase::ServerFire_Validate(const FVector& Origin, const FVector& ShootDir)
{
    // Basic validation: direction is normalized
    return ShootDir.IsNormalized();
}

void AWeaponBase::MulticastFireEffects_Implementation()
{
    if (MuzzleFlash) UGameplayStatics::SpawnEmitterAttached(MuzzleFlash, RootComponent);
    if (ShotSound) UGameplayStatics::PlaySoundAtLocation(this, ShotSound, GetActorLocation());
}

void AWeaponBase::OnRep_Ammo()
{
    // client side update for HUD etc.
}
