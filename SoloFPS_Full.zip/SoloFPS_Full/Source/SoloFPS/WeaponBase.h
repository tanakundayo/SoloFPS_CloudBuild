#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "WeaponBase.generated.h"

UCLASS()
class SOLOFPS_API AWeaponBase : public AActor
{
    GENERATED_BODY()
public:
    AWeaponBase();

    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
    virtual void Tick(float DeltaTime) override;
    void StartFire();
    void StopFire();
    void StartReload();

    UPROPERTY(EditDefaultsOnly, Category="Weapon")
    float Damage = 35.f;

    UPROPERTY(EditDefaultsOnly, Category="Weapon")
    float FireRate = 0.12f;

    UPROPERTY(EditDefaultsOnly, Category="Weapon")
    int32 MagazineSize = 30;

    UPROPERTY(EditDefaultsOnly, Category="Weapon")
    int32 ReserveAmmo = 90;

    UPROPERTY(EditDefaultsOnly, Category="Weapon")
    bool bIsAutomatic = true;

    UPROPERTY(EditDefaultsOnly, Category="Effects")
    class USoundBase* ShotSound;

    UPROPERTY(EditDefaultsOnly, Category="Effects")
    class UParticleSystem* MuzzleFlash;

    UPROPERTY(EditDefaultsOnly, Category="Effects")
    class UParticleSystem* ImpactEffect;

    UPROPERTY(EditDefaultsOnly, Category="Weapon")
    float Range = 10000.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Weapon")
    USceneComponent* WeaponRoot;

    UFUNCTION(BlueprintCallable, Category="Weapon")
    int32 GetCurrentAmmo() const { return CurrentAmmoInMag; }
    UFUNCTION(BlueprintCallable, Category="Weapon")
    int32 GetReserveAmmo() const { return CurrentReserve; }

    UFUNCTION(Server, Reliable, WithValidation)
    void ServerFire(const FVector& Origin, const FVector& ShootDir);

    UFUNCTION(NetMulticast, Unreliable)
    void MulticastFireEffects();

protected:
    virtual void BeginPlay() override;

    FTimerHandle TimerHandle_TimeBetweenShots;
    float LastFireTime;
    float TimeBetweenShots;

    UPROPERTY(ReplicatedUsing=OnRep_Ammo)
    int32 CurrentAmmoInMag;

    UPROPERTY(Replicated)
    int32 CurrentReserve;

    UFUNCTION()
    void OnRep_Ammo();

    void FireShot();
    bool CanFire() const;
    void ConsumeAmmo();

    AActor* MyOwnerActor;
};
