#include "BTTask_Shoot.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "AIController.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/Actor.h"

UBTTask_Shoot::UBTTask_Shoot()
{
    NodeName = "Shoot Target";
}

EBTNodeResult::Type UBTTask_Shoot::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
    AAIController* AICon = OwnerComp.GetAIOwner();
    if (!AICon) return EBTNodeResult::Failed;

    UBlackboardComponent* BB = OwnerComp.GetBlackboardComponent();
    if (!BB) return EBTNodeResult::Failed;

    UObject* TargetObj = BB->GetValueAsObject(TEXT("TargetActor"));
    AActor* TargetActor = Cast<AActor>(TargetObj);
    APawn* AIPawn = AICon->GetPawn();
    if (!AIPawn) return EBTNodeResult::Failed;
    if (!TargetActor) return EBTNodeResult::Failed;

    FVector Muzzle = AIPawn->GetActorLocation() + FVector(0,0,50.f);
    FVector Dir = (TargetActor->GetActorLocation() + FVector(0,0,50.f) - Muzzle).GetSafeNormal();
    FHitResult Hit;
    FCollisionQueryParams Params;
    Params.AddIgnoredActor(AIPawn);

    bool bHit = AIPawn->GetWorld()->LineTraceSingleByChannel(Hit, Muzzle, Muzzle + Dir * 5000.f, ECC_Visibility, Params);
    if (bHit && Hit.GetActor())
    {
        UGameplayStatics::ApplyPointDamage(Hit.GetActor(), Damage, Dir, Hit, AICon, AIPawn, nullptr);
    }

    return EBTNodeResult::Succeeded;
}
