#include "SoloFPSGameMode.h"

ASoloFPSGameMode::ASoloFPSGameMode()
{
    // default settings
}
