#include "DamageableComponent.h"
#include "Kismet/GameplayStatics.h"

UDamageableComponent::UDamageableComponent()
{
    PrimaryComponentTick.bCanEverTick = false;
}

void UDamageableComponent::BeginPlay()
{
    Super::BeginPlay();
    CurrentHP = MaxHP;
}

void UDamageableComponent::ApplyDamage(float DamageAmount)
{
    CurrentHP = FMath::Clamp(CurrentHP - DamageAmount, 0.f, MaxHP);
    OnDamage.Broadcast(GetOwner(), DamageAmount);
    if (CurrentHP <= 0.f)
    {
        OnDeath.Broadcast(GetOwner());
    }
}
