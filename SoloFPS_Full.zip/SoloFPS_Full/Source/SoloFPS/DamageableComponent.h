#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "DamageableComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnDeathSignature, AActor*, DeadActor);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnDamageSignature, AActor*, DamagedActor, float, DamageAmount);

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class SOLOFPS_API UDamageableComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    UDamageableComponent();

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Health")
    float MaxHP = 100.f;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Health")
    float CurrentHP;

    UPROPERTY(BlueprintAssignable, Category="Events")
    FOnDeathSignature OnDeath;

    UPROPERTY(BlueprintAssignable, Category="Events")
    FOnDamageSignature OnDamage;

    virtual void BeginPlay() override;

    UFUNCTION(BlueprintCallable, Category="Health")
    void ApplyDamage(float DamageAmount);
};
